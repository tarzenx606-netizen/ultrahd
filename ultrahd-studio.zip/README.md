# Ultra HD Studio 4K (MVP, untested build)
Kotlin + Compose + Media3 Transformer. Build via GitHub Actions (see .github/workflows/build.yml).
Implemented: video import (photo picker, no permissions), color preview + export, 720p-4K export (H.264/H.265),
voice cleanup (high-pass + noise gate + loudness), progress/cancel, save to Movies/UltraHD Studio, share.
Not implemented: AI upscaling, stabilization, 60 FPS, resume, echo reduction, project history.
