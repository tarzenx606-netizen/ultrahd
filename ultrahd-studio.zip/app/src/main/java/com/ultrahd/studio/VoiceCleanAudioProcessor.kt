package com.ultrahd.studio

import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.AudioProcessor.AudioFormat
import androidx.media3.common.audio.BaseAudioProcessor
import androidx.media3.common.util.UnstableApi
import java.nio.ByteBuffer
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.tanh

/**
 * Real (basic) DSP voice cleanup on 16-bit PCM:
 *  1. High-pass filter (~90 Hz) removes rumble, wind thump and low hum.
 *  2. Downward expander / noise gate lowers steady background noise between words.
 *  3. Optional makeup gain with a soft limiter for louder, even speech.
 * This is NOT an AI speech-enhancement model.
 */
@UnstableApi
class VoiceCleanAudioProcessor(
    private val strength: Float,   // 0..1 noise reduction amount
    private val loudness: Boolean
) : BaseAudioProcessor() {

    private var prevX = FloatArray(0)
    private var prevY = FloatArray(0)
    private var tmp = FloatArray(0)
    private var env = 0f
    private var gate = 1f

    override fun onConfigure(inputAudioFormat: AudioFormat): AudioFormat {
        if (inputAudioFormat.encoding != C.ENCODING_PCM_16BIT) {
            throw AudioProcessor.UnhandledAudioFormatException(inputAudioFormat)
        }
        val ch = inputAudioFormat.channelCount
        prevX = FloatArray(ch); prevY = FloatArray(ch); tmp = FloatArray(ch)
        return inputAudioFormat
    }

    override fun onFlush() {
        prevX.fill(0f); prevY.fill(0f); env = 0f; gate = 1f
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val ch = inputAudioFormat.channelCount
        val sr = inputAudioFormat.sampleRate.toFloat()
        val frames = inputBuffer.remaining() / (2 * ch)
        val out = replaceOutputBuffer(frames * 2 * ch)

        val dt = 1f / sr
        val rc = 1f / (2f * Math.PI.toFloat() * 90f)
        val hp = rc / (rc + dt)
        val decay = exp(-1f / (0.05f * sr))
        val openCoef = 1f / (0.01f * sr)
        val closeCoef = 1f / (0.15f * sr)
        val threshold = 0.004f + 0.02f * strength
        val floorGain = 1f - 0.85f * strength
        val makeup = if (loudness) 1.5f else 1f

        for (f in 0 until frames) {
            var level = 0f
            for (c in 0 until ch) {
                val x = inputBuffer.short.toFloat() / 32768f
                val y = hp * (prevY[c] + x - prevX[c])
                prevX[c] = x; prevY[c] = y
                tmp[c] = y
                level = max(level, abs(y))
            }
            env = max(level, env * decay)
            val target = if (env < threshold) floorGain else 1f
            gate += (target - gate) * (if (target > gate) openCoef else closeCoef)
            for (c in 0 until ch) {
                var v = tmp[c] * gate * makeup
                val a = abs(v)
                if (a > 0.9f) {
                    val s = if (v < 0) -1f else 1f
                    v = s * (0.9f + 0.1f * tanh((a - 0.9f) / 0.1f))
                }
                out.putShort((v.coerceIn(-1f, 1f) * 32767f).toInt().toShort())
            }
        }
        out.flip()
    }
}
