package com.ultrahd.studio

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.Player
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Brightness
import androidx.media3.effect.Contrast
import androidx.media3.effect.HslAdjustment
import androidx.media3.effect.Presentation
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.transformer.Composition
import androidx.media3.transformer.DefaultEncoderFactory
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.VideoEncoderSettings
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.delay
import java.io.File
import kotlin.concurrent.thread

private val Violet = Color(0xFF8B5CF6)
private val Blue = Color(0xFF3B82F6)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Violet, secondary = Blue,
                    background = Color.Black, surface = Color(0xFF0E0E16)
                )
            ) {
                Surface(modifier = Modifier.fillMaxSize(), color = Color.Black) { StudioScreen() }
            }
        }
    }
}

@UnstableApi
private fun colorEffects(b: Float, c: Float, s: Float): List<Effect> = listOf(
    Brightness(b), Contrast(c), HslAdjustment.Builder().adjustSaturation(s).build()
)

private fun bitrateFor(height: Int, h265: Boolean): Int {
    val mbps = when (height) { 2160 -> if (h265) 30 else 45; 1440 -> if (h265) 12 else 16
        1080 -> if (h265) 8 else 12; else -> if (h265) 4 else 6 }
    return mbps * 1_000_000
}

private fun saveToMovies(context: Context, file: File): Uri? {
    val values = ContentValues().apply {
        put(MediaStore.Video.Media.DISPLAY_NAME, file.name)
        put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
        put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/UltraHD Studio")
        put(MediaStore.Video.Media.IS_PENDING, 1)
    }
    val resolver = context.contentResolver
    val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values) ?: return null
    resolver.openOutputStream(uri)?.use { out -> file.inputStream().use { it.copyTo(out) } }
    values.clear(); values.put(MediaStore.Video.Media.IS_PENDING, 0)
    resolver.update(uri, values, null, null)
    file.delete()
    return uri
}

@androidx.annotation.OptIn(UnstableApi::class)
@Composable
fun StudioScreen() {
    val context = LocalContext.current
    var videoUri by remember { mutableStateOf<Uri?>(null) }
    var brightness by remember { mutableFloatStateOf(0.05f) }
    var contrast by remember { mutableFloatStateOf(0.1f) }
    var saturation by remember { mutableFloatStateOf(10f) }
    var height by remember { mutableStateOf(1080) }
    var h265 by remember { mutableStateOf(false) }
    var voice by remember { mutableStateOf(true) }
    var voiceStrength by remember { mutableFloatStateOf(0.5f) }
    var loudness by remember { mutableStateOf(true) }
    var showEnhanced by remember { mutableStateOf(true) }
    var status by remember { mutableStateOf("Pick a video to start.") }
    var progress by remember { mutableFloatStateOf(0f) }
    var exporting by remember { mutableStateOf(false) }
    var outputUri by remember { mutableStateOf<Uri?>(null) }
    var transformer by remember { mutableStateOf<Transformer?>(null) }
    var tempFile by remember { mutableStateOf<File?>(null) }
    var durationMs by remember { mutableStateOf(0L) }

    val player = remember { ExoPlayer.Builder(context).build() }
    DisposableEffect(player) {
        val l = object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_READY) durationMs = player.duration.coerceAtLeast(0)
            }
        }
        player.addListener(l)
        onDispose { player.removeListener(l); player.release() }
    }
    LaunchedEffect(videoUri) {
        videoUri?.let { player.setMediaItem(MediaItem.fromUri(it)); player.prepare() }
    }
    LaunchedEffect(showEnhanced, brightness, contrast, saturation) {
        player.setVideoEffects(if (showEnhanced) colorEffects(brightness, contrast, saturation) else emptyList())
    }
    LaunchedEffect(exporting) {
        while (exporting) {
            val h = ProgressHolder()
            if (transformer?.getProgress(h) == Transformer.PROGRESS_STATE_AVAILABLE) progress = h.progress / 100f
            delay(500)
        }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) { videoUri = uri; outputUri = null; status = "Video loaded." }
    }

    val bitrate = bitrateFor(height, h265)
    val estMb = bitrate / 8.0 * (durationMs / 1000.0) / 1_000_000.0

    fun startExport() {
        val src = videoUri ?: return
        val need = (bitrate / 8.0 * (durationMs / 1000.0) * 2.2).toLong()
        if (context.cacheDir.usableSpace < need) {
            status = "Not enough free storage (need about ${need / 1_000_000} MB). Free space or pick a lower quality."
            return
        }
        val dir = File(context.cacheDir, "exports").apply { mkdirs() }
        val out = File(dir, "UltraHD_${System.currentTimeMillis()}.mp4")
        tempFile = out
        val audio: List<AudioProcessor> =
            if (voice) listOf(VoiceCleanAudioProcessor(voiceStrength, loudness)) else emptyList()
        val video = colorEffects(brightness, contrast, saturation) + Presentation.createForHeight(height)
        val edited = EditedMediaItem.Builder(MediaItem.fromUri(src)).setEffects(Effects(audio, video)).build()
        val enc = DefaultEncoderFactory.Builder(context)
            .setRequestedVideoEncoderSettings(VideoEncoderSettings.Builder().setBitrate(bitrate).build())
            .build()
        val t = Transformer.Builder(context)
            .setVideoMimeType(if (h265) MimeTypes.VIDEO_H265 else MimeTypes.VIDEO_H264)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
            .setEncoderFactory(enc)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    exporting = false; progress = 1f; status = "Saving to Movies/UltraHD Studio..."
                    thread {
                        val uri = try { saveToMovies(context, out) } catch (e: Exception) { null }
                        outputUri = uri
                        status = if (uri != null) "Done. Saved to Movies/UltraHD Studio." else "Export finished but saving failed."
                    }
                }
                override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                    exporting = false; out.delete()
                    status = "Export failed: ${exportException.message}. Try 1080p or H.264."
                }
            }).build()
        transformer = t; exporting = true; progress = 0f; outputUri = null
        status = "Exporting..."
        t.start(edited, out.absolutePath)
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("Ultra HD Studio 4K", style = MaterialTheme.typography.headlineSmall, color = Violet)
        Button(onClick = {
            picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly))
        }, modifier = Modifier.fillMaxWidth().height(52.dp), enabled = !exporting) { Text("Import video") }

        if (videoUri != null) {
            AndroidView(
                factory = { PlayerView(it).apply { this.player = player } },
                modifier = Modifier.fillMaxWidth().height(220.dp)
            )
            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                Switch(showEnhanced, { showEnhanced = it })
                Text("  Preview: " + if (showEnhanced) "enhanced" else "original")
            }
        }

        Text("Video", color = Blue)
        SliderRow("Brightness", brightness, -0.3f..0.3f) { brightness = it }
        SliderRow("Contrast", contrast, -0.3f..0.5f) { contrast = it }
        SliderRow("Color", saturation, -50f..50f) { saturation = it }

        Text("Resolution (keeps aspect ratio, never stretches)", color = Blue)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf(720, 1080, 1440, 2160).forEach { h ->
                FilterChip(height == h, { height = h }, label = { Text(if (h == 2160) "4K" else "${h}p") })
            }
        }
        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            Switch(h265, { h265 = it }); Text("  H.265 (smaller file; falls back to H.264 if unsupported)")
        }
        Text("Upscaling enlarges the picture. It does not add real detail that was not recorded.",
            style = MaterialTheme.typography.bodySmall)

        Text("Voice", color = Blue)
        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            Switch(voice, { voice = it }); Text("  Clean voice (off = keep original audio)")
        }
        if (voice) {
            SliderRow("Noise reduction", voiceStrength, 0f..1f) { voiceStrength = it }
            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                Switch(loudness, { loudness = it }); Text("  Louder, even volume")
            }
        }

        if (durationMs > 0) Text("Estimated size: %.0f MB at %d Mbps".format(estMb, bitrate / 1_000_000))
        if (exporting) {
            LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth())
            Text("${(progress * 100).toInt()}%")
            OutlinedButton(onClick = {
                transformer?.cancel(); exporting = false; tempFile?.delete(); status = "Export cancelled."
            }, modifier = Modifier.fillMaxWidth()) { Text("Cancel") }
        } else {
            Button(onClick = { startExport() }, enabled = videoUri != null,
                modifier = Modifier.fillMaxWidth().height(60.dp)) { Text("EXPORT") }
        }
        Text(status)
        outputUri?.let { u ->
            Button(onClick = {
                val i = Intent(Intent.ACTION_SEND).apply {
                    type = "video/mp4"; putExtra(Intent.EXTRA_STREAM, u)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                context.startActivity(Intent.createChooser(i, "Share video"))
            }, modifier = Modifier.fillMaxWidth()) { Text("Share") }
            OutlinedButton(onClick = { player.setMediaItem(MediaItem.fromUri(u)); player.prepare(); player.play() },
                modifier = Modifier.fillMaxWidth()) { Text("Play exported video") }
        }
        OutlinedButton(onClick = {
            File(context.cacheDir, "exports").deleteRecursively(); status = "Temporary files deleted."
        }, modifier = Modifier.fillMaxWidth(), enabled = !exporting) { Text("Delete temporary files") }
        Text("All processing happens on your phone. Nothing is uploaded.", style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun SliderRow(label: String, value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
    Column {
        Text("$label: %.2f".format(value), style = MaterialTheme.typography.bodySmall)
        Slider(value = value, onValueChange = onChange, valueRange = range)
    }
}
